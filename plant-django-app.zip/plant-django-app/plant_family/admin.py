from django.contrib import admin
from .models import Family

# Register your models here.


# Register your models here.

admin.site.register(Family)