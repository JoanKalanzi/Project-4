from django.contrib import admin
from .models import Picture

admin.site.register(Picture)

